export class Livro {
    titulo:string;
    subtitulo:string;
    capa:string;
    editora:string;
    autor:string;
    isbn:string;
    publicacao:string;
    paginas:string;
}
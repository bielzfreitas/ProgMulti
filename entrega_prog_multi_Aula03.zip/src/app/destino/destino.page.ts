import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-destino',
  templateUrl: './destino.page.html',
  styleUrls: ['./destino.page.scss'],
})
export class DestinoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

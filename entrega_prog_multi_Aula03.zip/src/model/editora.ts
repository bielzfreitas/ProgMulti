export interface Editora {
    nome:String;
    descricao:String;
}
export interface Autor {
    nome:String;
    nascimento:number;
    descricao:String
}
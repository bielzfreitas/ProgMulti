package br.usjt.hellospringboot;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HellospringbootApplicationTests {

	@Test
	public void contextLoads() {
	}
	<ion-slides pager> 	 <ion-slide style="background-color: green">  <h2>pagina 1</h2> 	    </ion-slide>
	<div>	<p>Algum	livro </p>	<p>Mais	aqui tem livro</p>	  
		goToTabsPage	(){	this.navCtrl.push(TabsPage);
	  <ion-slide style="background-color: blue"> 	      <h2>pagina 2 2</h2> 	   
	   </ion-slide> 	   
	   <div>	<p>Algum	prourar</p>	<p>Mais por editor 	</p>
	   	goToTabsPage	(){	this.navCtrl.push(TabsPage);
	 <ion-slide style="background-color: red"> 	 <h2>pagina 3</h2> 	    </ion-slide> 	
	   </ion-slides>
	   <div>	<p>Algum	aqui tem local </p>	<p>Mais	onde tem o livro </p
	   	goToTabsPage	(){	this.navCtrl.push(TabsPage);


}
	
